"""gymManagement1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from gym.views import *
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from gym import views
urlpatterns = [
    path('admin/', admin.site.urls),
    #path('home',views.Home,name = 'home'),
    path('about/',views.About,name = 'about'),

    path('contact/',views.Contact,name ='contact'),
    path('feedback/',Feedback,name ='feedback'),
    path('delete_feedback(?P<int:pid>)',Delete_Feedback,name ='delete_feedback'),
    
    path('',views.Index,name ='index'),
    path('dashboard',views.Dashboard,name ='dashboard'),
    path('gym/',views.Gym,name ='gym'),
    path('price/',views.Price,name ='price'),
    path('admin_login',views.login,name ='login'),
    path('logout/',views.logout_admin,name ='logout'),
    
    
    path('add_enquiry/',Add_Enquiry,name ='add_enquiry'),
    path('view_enquiry/',View_Enquiry,name ='view_enquiry'),
    path('delete_enquiry(?P<int:pid>)',Delete_Enquiry,name ='delete_enquiry'),
    path('add_enquiry/view_enquiry',View_Enquiry,name ='view_enquiry'),
    
    path('add_equipment/',Add_Equipment,name ='add_equipment'),
    path('view_equipment/',View_Equipment,name ='view_equipment'),
    path('delete_equipment(?P<int:pid>)',Delete_Equipment,name ='delete_equipment'),
    path('add_equipment/view_equipment/',View_Equipment,name ='view_equipment'),
    

    path('add_plan/',Add_Plan,name ='add_plan'),
    path('view_plan/',View_Plan,name ='view_plan'),
    path('delete_plan(?P<int:pid>)',Delete_Plan,name ='delete_plan'),
    path('add_plan/view_plan/',View_Plan,name ='view_plan'),
    

    path('add_member/',Add_Member,name ='add_member'),
    path('view_member/',View_Member,name ='view_member'),
    path('delete_member(?P<int:pid>)',Delete_Member,name ='delete_member'),
    path('add_member/view_member/',View_Member,name ='view_member'),
    
    path('add_class/',Add_Class,name ='add_class'),
    path('view_class/',View_Class,name ='view_class'),
    path('delete_classes(?P<int:pid>)',Delete_Class,name ='delete_classes'),
    path('add_class/view_class/',View_Class,name ='view_class'),
    

]

urlpatterns += staticfiles_urlpatterns()