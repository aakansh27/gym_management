from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate,logout,login
from django.contrib import messages
from .models import *


# Create your views here.

def Dashboard(request):
    if not request.user.is_staff:
        return redirect('login')

    enquiry = Enquiry.objects.all()
    plan = Plan.objects.all()
    equipment = Equipment.objects.all()
    member = Member.objects.all()

    

    e1 = 0
    p1 = 0
    eq1 = 0
    m1 = 0

    for i in enquiry:
        e1 = e1 + 1
    for i in plan:
        p1 =  p1 + 1
    for i in equipment:
        eq1 = eq1 + 1
    for i in member:
        m1 = m1 + 1
    d = {'e':e1,'p1':p1,'eq1':eq1,'m1':m1}
    return render(request, 'dashboard.html', d)


def About(request):
    return render(request,'about.html')

def Contact(request):
    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        e = request.POST['emailid']
        c = request.POST['contact']
        
        m = request.POST['text']
        
        try:
            Feedbacks.objects.create(name=n,emailid=e,contact=c,text=m)
            error="no"
        except:
            error="yes"
    d = {'error':error}
    return render(request,'contact.html', d)

def Feedback(request):
    feedback = Feedbacks.objects.all()
    d = {'feedback':feedback}
    return render(request, 'feedback.html', d)

def Delete_Feedback(request,pid ):
    
    
    feedback = Feedbacks.objects.get(id=pid)
    feedback.delete()
    return redirect('feedback')


def Index(request):
    if request.user.is_staff:
        return redirect('dashboard')
     

    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        e = request.POST['emailid']
        c = request.POST['contact']
        m = request.POST['text']
        
        try:
            Feedbacks.objects.create(name=n,emailid=e,contact=c,text=m)
            error="no"
        except:
            error="yes"
    d = {'error':error} 
    return render(request, 'index.html')

def Gym(request):
    
    return render(request,'gym.html')

def Price(request):
    
    return render(request,'price.html')

def login(request):
    if request.method=='POST':
        u = request.POST['uname']
        p = request.POST['pwd']
        user = auth.authenticate(username=u,password=p)
        if user is not None:
            auth.login(request, user)
            return redirect("dashboard")
        else:
            messages.info(request,'Invalid Username or Password')
            return redirect('login')

    else:
         return render(request,'login.html')               


def logout_admin(request):
    if not request.user.is_staff:
        return redirect('index')
    logout(request)
    return redirect('index')


def Dashboard(request):
    return render(request,'dashboard.html')


def Add_Enquiry(request):
    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        c = request.POST['contact']
        e = request.POST['emailid']
        a = request.POST['age']
        g = request.POST['gender']
        ad = request.POST['address']
        try:
            Enquiry.objects.create(name=n,contact=c,emailid=e,age=a,gender=g,address=ad)
            error="no"
        except:
            error="yes"
    d = {'error':error}
    return render(request, 'add_enquiry.html', d)


def View_Enquiry(request):
    
    
    enq = Enquiry.objects.all()
    d = {'enq':enq}
    return render(request, 'view_enquiry.html', d)


def Delete_Enquiry(request,pid ):
    
    
    enquiry = Enquiry.objects.get(id=pid)
    enquiry.delete()
    return redirect('view_enquiry')

def Add_Equipment(request):
    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        p = request.POST['price']
        u = request.POST['unit']
        d = request.POST['date']
        de = request.POST['description']
        try:
            Equipment.objects.create(name=n,price=p,unit=u,date=d,description=de)
            error="no"
        except:
            error="yes"
    f = {'error':error}
    return render(request, 'add_equipment.html', f)


def View_Equipment(request):

    equipment = Equipment.objects.all()
    f = {'equipment':equipment}
    return render(request, 'view_equipment.html', f)


def Delete_Equipment(request,pid ):

    
    equipment = Equipment.objects.get(id=pid)
    equipment.delete()
    return redirect('view_equipment')

def Add_Plan(request):
    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        a = request.POST['amount']
        d = request.POST['duration']
        try:
            Plan.objects.create(name=n,amount=a,duration=d)
            error="no"
        except:
            error="yes"
    f = {'error':error}
    return render(request, 'add_plan.html', f)


def View_Plan(request):

    plan = Plan.objects.all()
    f = {'plan':plan}
    return render(request, 'view_plan.html', f)


def Delete_Plan(request,pid ):

    
    plan = Plan.objects.get(id=pid)
    plan.delete()
    return redirect('view_plan')

def Add_Member(request):
    error=""
    
    plan1 = Plan.objects.all()

    if request.method=='POST':
        n = request.POST['name']
        c = request.POST['contact']
        e = request.POST['emailid']
        a = request.POST['age']
        g = request.POST['gender']
        p = request.POST['plan']
        j = request.POST['joindate']
        ex = request.POST['expiredate']
        i = request.POST['initialamount']
        plan = Plan.objects.filter(name=p).first()      
        try:
            Member.objects.create(name=n,contact=c,emailid=e,age=a,gender=g,plan=plan,joindate=j,expiredate=ex,initialamount=i)
            error="no"
        except:
            error="yes"
    f = {'error':error,'plan':plan1}
    return render(request, 'add_member.html', f)


def View_Member(request):

    member = Member.objects.all()
    f = {'member':member}
    return render(request, 'view_member.html', f)


def Delete_Member(request,pid ):

    
    member = Member.objects.get(id=pid)
    member.delete()
    return redirect('view_member')


def Add_Class(request):
    error=""
    
    if request.method=='POST':
        n = request.POST['name']
        a = request.POST['session']
        d = request.POST['duration']
        try:
            Classes.objects.create(name=n,session=s,duration=d)
            error="no"
        except:
            error="yes"
    f = {'error':error}
    return render(request, 'add_class.html', f)


def View_Class(request):

    classes = Classes.objects.all()
    f = {'classes':classes}
    return render(request, 'view_class.html', f)


def Delete_Class(request,pid ):

    
    classes = Classes.objects.get(id=pid)
    classes.delete()
    return redirect('view_class')

